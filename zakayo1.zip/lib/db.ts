import path from "path"
import { v4 as uuidv4 } from "uuid"

const dataDir = path.join(process.cwd(), "data")
const dbPath = path.join(dataDir, "db.json")
const uploadsDir = path.join(process.cwd(), "public", "uploads")

export interface Product {
  id: string
  name: string
  description: string
  price: number
  image: string
  category: string
  featured: boolean
  inStock: boolean
}

export interface Order {
  id: string
  userId: string
  products: { productId: string; quantity: number }[]
  total: number
  status: "pending" | "processing" | "shipped" | "delivered"
  createdAt: string
  transactionId: string
}

export interface User {
  id: string
  name: string
  email: string
  role: "user" | "admin"
  wishlist?: string[]
}

export interface Payment {
  id: string
  orderId: string
  amount: number
  method: string
  status: "pending" | "successful" | "failed"
  createdAt: string
  transactionId: string
}

export interface Review {
  id: string
  productId: string
  userId: string
  userName: string
  rating: number
  comment: string
  createdAt: string
}

interface DB {
  products: Product[]
  orders: Order[]
  users: User[]
  payments: Payment[]
  reviews: Review[]
}

export function readDb(): DB {
  // Placeholder: In a real app, this would read from a database
  return { products: [], orders: [], users: [], payments: [], reviews: [] }
}

export function writeDb(db: DB) {
  // Placeholder: In a real app, this would write to a database
  console.log("Writing to database:", db)
}

export function getProducts(): Product[] {
  const db = readDb()
  return db.products
}

export function getProduct(id: string): Product | undefined {
  const db = readDb()
  return db.products.find((p) => p.id === id)
}

export async function addProduct(product: Omit<Product, "id">): Promise<Product> {
  const db = readDb()
  const newProduct = { ...product, id: uuidv4() }
  db.products.push(newProduct)
  writeDb(db)
  return newProduct
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<Product | null> {
  const db = readDb()
  const index = db.products.findIndex((p) => p.id === id)
  if (index === -1) return null
  db.products[index] = { ...db.products[index], ...updates }
  writeDb(db)
  return db.products[index]
}

export function deleteProduct(id: string): boolean {
  const db = readDb()
  const initialLength = db.products.length
  db.products = db.products.filter((p) => p.id !== id)
  if (db.products.length === initialLength) return false
  writeDb(db)
  return true
}

export async function uploadImage(file: File): Promise<string> {
  // Placeholder: In a real app, this would upload the image to a storage service
  console.log("Uploading image:", file.name)
  return `/uploads/${file.name}`
}

export function getOrders(): Order[] {
  const db = readDb()
  return db.orders
}

export function addOrder(order: Omit<Order, "id">): Order {
  const db = readDb()
  const newOrder = { ...order, id: uuidv4() }
  db.orders.push(newOrder)
  writeDb(db)
  return newOrder
}

export function getUsers(): User[] {
  const db = readDb()
  return db.users
}

export function addUser(user: Omit<User, "id">): User {
  const db = readDb()
  const newUser = { ...user, id: uuidv4() }
  db.users.push(newUser)
  writeDb(db)
  return newUser
}

export function getUserById(id: string): User | undefined {
  const db = readDb()
  return db.users.find((u) => u.id === id)
}

export function getOrdersByUserId(userId: string): Order[] {
  const db = readDb()
  return db.orders.filter((o) => o.userId === userId)
}

export function getPayments(): Payment[] {
  const db = readDb()
  return db.payments
}

export function addPayment(payment: Omit<Payment, "id">): Payment {
  const db = readDb()
  const newPayment = { ...payment, id: uuidv4() }
  db.payments.push(newPayment)
  writeDb(db)
  return newPayment
}

export function getOrderById(id: string): Order | undefined {
  const db = readDb()
  return db.orders.find((o) => o.id === id)
}

export function getWishlistByUserId(userId: string): Product[] {
  const db = readDb()
  const user = db.users.find((u) => u.id === userId)
  if (!user || !user.wishlist) return []
  return user.wishlist.map((productId) => db.products.find((p) => p.id === productId)).filter(Boolean) as Product[]
}

export function searchProducts(query: string): Product[] {
  const db = readDb()
  return db.products.filter(
    (product) =>
      product.name.toLowerCase().includes(query.toLowerCase()) ||
      product.description.toLowerCase().includes(query.toLowerCase()) ||
      product.category.toLowerCase().includes(query.toLowerCase()),
  )
}

export function getProductReviews(productId: string): Review[] {
  const db = readDb()
  return db.reviews.filter((review) => review.productId === productId)
}

export function addReviewToDb(review: Omit<Review, "id">): Review {
  const db = readDb()
  const newReview = { ...review, id: uuidv4() }
  db.reviews.push(newReview)
  writeDb(db)
  return newReview
}

