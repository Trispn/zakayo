import { ProductGrid } from "@/components/product-grid"

export default function SalePage() {
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">SALE</h1>
      <ProductGrid />
    </div>
  )
}

