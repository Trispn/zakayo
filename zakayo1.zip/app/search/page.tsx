import { searchProducts } from "@/lib/db"
import { ProductCard } from "@/components/product-card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default async function SearchPage({
  searchParams,
}: {
  searchParams: { q: string }
}) {
  const query = searchParams.q || ""
  const products = await searchProducts(query)

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">Search Results</h1>
      <form action="/search" method="get" className="mb-6 flex gap-2">
        <Input type="search" name="q" defaultValue={query} placeholder="Search products..." className="flex-grow" />
        <Button type="submit">Search</Button>
      </form>
      {products.length === 0 ? (
        <p>No products found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}

