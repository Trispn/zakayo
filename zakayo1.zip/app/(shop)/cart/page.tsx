"use client"

import Image from "next/image"
import Link from "next/link"
import { Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const cartItems = [
  {
    id: 1,
    name: "Sunscreen SPF 50 Lotion For Babies + Kiddos",
    brand: "SUPERGOOP!",
    price: 48.34,
    quantity: 1,
    image: "/placeholder.svg",
  },
  // Add more items as needed
]

export default function CartPage() {
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">SHOPPING BAG (1)</h1>
      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          {cartItems.map((item) => (
            <div key={item.id} className="flex gap-4 py-4 border-b">
              <div className="w-24 h-24 flex-shrink-0">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.name}
                  width={96}
                  height={96}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-grow">
                <h3 className="font-medium">{item.brand}</h3>
                <p>{item.name}</p>
                <p className="mt-1">AU$ {item.price.toFixed(2)}</p>
                <div className="mt-2 flex items-center gap-2">
                  <Select defaultValue={item.quantity.toString()}>
                    <SelectTrigger className="w-20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5].map((num) => (
                        <SelectItem key={num} value={num.toString()}>
                          {num}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button variant="ghost" size="sm">
                    <Trash2 className="h-4 w-4" />
                    <span className="sr-only">Remove item</span>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div>
          <div className="bg-gray-100 p-6 rounded-lg">
            <h2 className="text-lg font-semibold mb-4">ORDER SUMMARY</h2>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Subtotal (1)</span>
                <span>AU$ 48.34</span>
              </div>
              <div className="flex justify-between">
                <span>Estimated Shipping</span>
                <span>AU$ 16.11</span>
              </div>
              <div className="flex justify-between font-semibold">
                <span>Estimated Total</span>
                <span>AU$ 64.45</span>
              </div>
            </div>
            <Button className="w-full mt-6 bg-black text-white hover:bg-gray-800">PROCEED TO CHECKOUT</Button>
          </div>
          <div className="mt-6">
            <p className="text-sm text-gray-600">FREE international shipping for orders above $100 USD</p>
            <div className="flex gap-2 mt-2">
              <Image src="/visa.svg" alt="Visa" width={40} height={25} />
              <Image src="/mastercard.svg" alt="Mastercard" width={40} height={25} />
              <Image src="/amex.svg" alt="American Express" width={40} height={25} />
              <Image src="/discover.svg" alt="Discover" width={40} height={25} />
              <Image src="/jcb.svg" alt="JCB" width={40} height={25} />
              <Image src="/paypal.svg" alt="PayPal" width={40} height={25} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

