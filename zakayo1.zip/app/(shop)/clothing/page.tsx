import { ProductGrid } from "@/components/product-grid"
import { Filters } from "@/components/filters"
import { Sorting } from "@/components/sorting"

export default function ClothingPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">MOOD ENHANCING CLOTHING</h1>
      <div className="flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-1/4">
          <Filters />
        </aside>
        <div className="flex-1">
          <div className="flex justify-between items-center mb-6">
            <p className="text-sm text-gray-500">Showing 1-24 of 100 products</p>
            <Sorting />
          </div>
          <ProductGrid />
        </div>
      </div>
    </div>
  )
}

