import { getOrderById } from "@/lib/db"
import { notFound } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default async function OrderConfirmationPage({ params }: { params: { id: string } }) {
  const order = await getOrderById(params.id)

  if (!order) {
    notFound()
  }

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">Order Confirmation</h1>
      <Card>
        <CardHeader>
          <CardTitle>Order #{order.id}</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            <strong>Date:</strong> {new Date(order.createdAt).toLocaleString()}
          </p>
          <p>
            <strong>Status:</strong> {order.status}
          </p>
          <p>
            <strong>Total:</strong> ${order.total.toFixed(2)}
          </p>
          <p>
            <strong>Transaction ID:</strong> {order.transactionId}
          </p>
          <h3 className="font-semibold mt-4 mb-2">Ordered Items:</h3>
          <ul>
            {order.products.map((item, index) => (
              <li key={index}>
                Product ID: {item.productId}, Quantity: {item.quantity}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

