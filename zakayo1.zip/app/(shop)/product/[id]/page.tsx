"use client"

import { useState } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ProductPage() {
  const [currentImage, setCurrentImage] = useState(0)
  const images = ["/placeholder.svg", "/placeholder.svg", "/placeholder.svg", "/placeholder.svg"]

  return (
    <div className="container py-8">
      <div className="grid gap-8 lg:grid-cols-2">
        <div className="relative">
          <div className="aspect-[3/4] overflow-hidden">
            <Image
              src={images[currentImage] || "/placeholder.svg"}
              alt="Product image"
              width={600}
              height={800}
              className="h-full w-full object-cover"
            />
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-4 top-1/2 h-8 w-8 -translate-y-1/2 rounded-full bg-white/70 hover:bg-white"
            onClick={() => setCurrentImage((prev) => (prev === 0 ? images.length - 1 : prev - 1))}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-1/2 h-8 w-8 -translate-y-1/2 rounded-full bg-white/70 hover:bg-white"
            onClick={() => setCurrentImage((prev) => (prev === images.length - 1 ? 0 : prev + 1))}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <div className="mt-4 flex gap-4 overflow-auto">
            {images.map((image, index) => (
              <button
                key={index}
                className={`relative aspect-square w-20 flex-shrink-0 overflow-hidden ${
                  currentImage === index ? "border-2 border-black" : ""
                }`}
                onClick={() => setCurrentImage(index)}
              >
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`Product image ${index + 1}`}
                  width={80}
                  height={80}
                  className="h-full w-full object-cover"
                />
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold">ISABEL MARANT</h1>
            <h2 className="text-xl">Helene Dress</h2>
            <p className="mt-2 text-xl font-bold">AU$ 2,400.88</p>
          </div>
          <div className="space-y-4">
            <div>
              <Label>Size</Label>
              <RadioGroup defaultValue="36" className="mt-2 flex flex-wrap gap-2">
                {[34, 36, 38, 40, 42].map((size) => (
                  <Label
                    key={size}
                    htmlFor={`size-${size}`}
                    className="cursor-pointer rounded-md border p-2 hover:bg-gray-100 [&:has(:checked)]:bg-black [&:has(:checked)]:text-white"
                  >
                    <RadioGroupItem value={size.toString()} id={`size-${size}`} className="sr-only" />
                    {size}
                  </Label>
                ))}
              </RadioGroup>
            </div>
            <div>
              <Label>Color</Label>
              <RadioGroup defaultValue="black" className="mt-2 flex flex-wrap gap-2">
                {["Black & Silver"].map((color) => (
                  <Label
                    key={color}
                    htmlFor={`color-${color}`}
                    className="cursor-pointer rounded-md border p-2 hover:bg-gray-100 [&:has(:checked)]:bg-black [&:has(:checked)]:text-white"
                  >
                    <RadioGroupItem value={color.toLowerCase()} id={`color-${color}`} className="sr-only" />
                    {color}
                  </Label>
                ))}
              </RadioGroup>
            </div>
          </div>
          <div className="flex gap-4">
            <Button className="flex-1 bg-black text-white hover:bg-gray-800">ADD TO BAG</Button>
            <Button variant="outline" size="icon">
              <Heart className="h-4 w-4" />
              <span className="sr-only">Add to wishlist</span>
            </Button>
          </div>
          <Tabs defaultValue="details">
            <TabsList className="w-full">
              <TabsTrigger value="details" className="flex-1">
                Details
              </TabsTrigger>
              <TabsTrigger value="styled" className="flex-1">
                Styled With
              </TabsTrigger>
              <TabsTrigger value="designer" className="flex-1">
                Designer Info
              </TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="mt-4">
              <div className="prose max-w-none">
                <p>
                  Introducing the Helene Dress by Isabel Marant, a perfect blend of style and sophistication. This dress
                  features intricate detailing and premium materials for a luxurious look and feel.
                </p>
              </div>
            </TabsContent>
            <TabsContent value="styled" className="mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="aspect-square">
                  <Image
                    src="/placeholder.svg"
                    alt="Styled with item"
                    width={200}
                    height={200}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="aspect-square">
                  <Image
                    src="/placeholder.svg"
                    alt="Styled with item"
                    width={200}
                    height={200}
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>
            </TabsContent>
            <TabsContent value="designer" className="mt-4">
              <div className="prose max-w-none">
                <p>
                  Isabel Marant is a French fashion designer known for her bohemian aesthetics and comfortable yet chic
                  clothing.
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

