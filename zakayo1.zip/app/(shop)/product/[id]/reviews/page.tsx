import { getProductReviews } from "@/lib/db"
import { StarRating } from "@/components/star-rating"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default async function ProductReviewsPage({ params }: { params: { id: string } }) {
  const reviews = await getProductReviews(params.id)

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">Product Reviews</h1>
      {reviews.length === 0 ? (
        <p>No reviews yet.</p>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <Card key={review.id}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{review.userName}</span>
                  <StarRating rating={review.rating} />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{review.comment}</p>
                <p className="text-sm text-gray-500 mt-2">{new Date(review.createdAt).toLocaleDateString()}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

