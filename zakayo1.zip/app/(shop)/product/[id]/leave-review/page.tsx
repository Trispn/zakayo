"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { StarRating } from "@/components/star-rating"
import { addReview } from "@/lib/api"

export default function LeaveReviewPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const [rating, setRating] = useState(0)
  const [comment, setComment] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await addReview({
        productId: params.id,
        rating,
        comment,
      })
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      })
      router.push(`/product/${params.id}`)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">Leave a Review</h1>
      <form onSubmit={handleSubmit} className="space-y-4 max-w-md">
        <div>
          <label className="block mb-2">Rating</label>
          <StarRating rating={rating} onRatingChange={setRating} editable />
        </div>
        <div>
          <label htmlFor="comment" className="block mb-2">
            Your Review
          </label>
          <Textarea id="comment" value={comment} onChange={(e) => setComment(e.target.value)} required />
        </div>
        <Button type="submit">Submit Review</Button>
      </form>
    </div>
  )
}

