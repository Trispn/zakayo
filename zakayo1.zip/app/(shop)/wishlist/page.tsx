import { getWishlistByUserId } from "@/lib/db"
import { ProductCard } from "@/components/product-card"

export default async function WishlistPage() {
  // In a real app, you'd get the user ID from the authenticated session
  const userId = "user123"
  const wishlist = await getWishlistByUserId(userId)

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">My Wishlist</h1>
      {wishlist.length === 0 ? (
        <p>Your wishlist is empty.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {wishlist.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}

