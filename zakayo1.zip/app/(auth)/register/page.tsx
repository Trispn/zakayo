"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"

export default function RegisterPage() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault()
    setIsLoading(true)

    // Add registration logic here

    setTimeout(() => {
      setIsLoading(false)
      router.push("/auth/login")
    }, 3000)
  }

  return (
    <div className="container max-w-md mx-auto mt-10">
      <h1 className="text-2xl font-bold mb-6">CREATE AN ACCOUNT</h1>
      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <Label htmlFor="email">Email address</Label>
          <Input id="email" type="email" placeholder="email address" required />
        </div>
        <div>
          <Label htmlFor="create-password">Create a password</Label>
          <Input id="create-password" type="password" placeholder="create a password" required />
        </div>
        <div>
          <Label htmlFor="verify-password">Verify password</Label>
          <Input id="verify-password" type="password" placeholder="verify your password" required />
        </div>
        <RadioGroup defaultValue="both">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="women" id="women" />
            <Label htmlFor="women">Women</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="men" id="men" />
            <Label htmlFor="men">Men</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="both" id="both" />
            <Label htmlFor="both">Both</Label>
          </div>
        </RadioGroup>
        <div className="flex items-center space-x-2">
          <Checkbox id="newsletter" />
          <label htmlFor="newsletter" className="text-sm">
            Be the first to know about new arrivals, sales & promos by submitting your email. You can opt out at any
            time.
          </label>
        </div>
        <Button className="w-full bg-black text-white" type="submit" disabled={isLoading}>
          {isLoading ? "Creating account..." : "AGREE AND CONTINUE"}
        </Button>
      </form>
      <div className="mt-4 text-sm">
        By signing up or clicking "Agree and Continue", you agree to our{" "}
        <Link href="/terms" className="text-blue-600 hover:underline">
          Terms of Service
        </Link>
        . Please also read our{" "}
        <Link href="/privacy" className="text-blue-600 hover:underline">
          Privacy Policy
        </Link>
        .
      </div>
    </div>
  )
}

