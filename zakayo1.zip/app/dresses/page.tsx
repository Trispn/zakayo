import { ProductGrid } from "@/components/product-grid"

export default function DressesPage() {
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">DRESSES</h1>
      <ProductGrid />
    </div>
  )
}

