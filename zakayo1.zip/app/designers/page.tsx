import Link from "next/link"

const designers = [
  "ISABEL MARANT",
  "BURBERRY",
  "SIEDRES",
  "SUPERGOOP!",
  "BALENCIAGA",
  "GUCCI",
  "PRADA",
  "SAINT LAURENT",
]

export default function DesignersPage() {
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">DESIGNERS</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {designers.map((designer) => (
          <Link
            key={designer}
            href={`/designers/${designer.toLowerCase().replace(" ", "-")}`}
            className="text-lg hover:text-blue-600 transition-colors"
          >
            {designer}
          </Link>
        ))}
      </div>
    </div>
  )
}

