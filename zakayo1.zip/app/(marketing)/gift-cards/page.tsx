"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

export default function GiftCardsPage() {
  const [amount, setAmount] = useState("")
  const [recipientEmail, setRecipientEmail] = useState("")
  const [message, setMessage] = useState("")
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically process the gift card purchase
    console.log({ amount, recipientEmail, message })
    toast({
      title: "Gift Card Purchased",
      description: "Your gift card has been sent to the recipient.",
    })
    setAmount("")
    setRecipientEmail("")
    setMessage("")
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Purchase a Gift Card</h1>
      <form onSubmit={handleSubmit} className="max-w-md space-y-4">
        <div>
          <label htmlFor="amount" className="block mb-2">
            Amount
          </label>
          <Select onValueChange={setAmount} required>
            <SelectTrigger>
              <SelectValue placeholder="Select amount" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="25">$25</SelectItem>
              <SelectItem value="50">$50</SelectItem>
              <SelectItem value="100">$100</SelectItem>
              <SelectItem value="200">$200</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label htmlFor="recipientEmail" className="block mb-2">
            Recipient's Email
          </label>
          <Input
            id="recipientEmail"
            type="email"
            value={recipientEmail}
            onChange={(e) => setRecipientEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="message" className="block mb-2">
            Message (optional)
          </label>
          <Input id="message" value={message} onChange={(e) => setMessage(e.target.value)} />
        </div>
        <Button type="submit">Purchase Gift Card</Button>
      </form>
    </div>
  )
}

