import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function AboutPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">About Zakayo Apparel</h1>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Our Story</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              Zakayo Apparel was founded in 2023 with a vision to provide high-quality, stylish clothing to
              fashion-conscious individuals. Our journey began with a small collection and has since grown into a
              diverse range of apparel and accessories.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Our Mission</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              At Zakayo Apparel, our mission is to empower individuals to express their unique style through our
              carefully curated collections. We strive to offer sustainable and ethically produced fashion that doesn't
              compromise on quality or design.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

