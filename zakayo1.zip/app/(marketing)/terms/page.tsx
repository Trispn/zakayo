export default function TermsOfServicePage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Terms of Service</h1>
      <div className="prose max-w-none">
        <p>Last updated: May 20, 2023</p>
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing and using Zakayo Apparel's website and services, you agree to be bound by these Terms of Service.
        </p>
        <h2>2. Use of the Website</h2>
        <p>
          You agree to use our website for lawful purposes only and in a way that does not infringe upon or restrict
          others' use and enjoyment of the website.
        </p>
        <h2>3. Product Information</h2>
        <p>
          We strive to provide accurate product information, but we do not warrant that product descriptions or other
          content is accurate, complete, reliable, current, or error-free.
        </p>
        <h2>4. Pricing and Availability</h2>
        <p>
          All prices are subject to change without notice. We reserve the right to modify or discontinue any product
          without notice.
        </p>
        <h2>5. Intellectual Property</h2>
        <p>
          All content on this website, including text, graphics, logos, and images, is the property of Zakayo Apparel
          and protected by copyright laws.
        </p>
        <h2>6. Limitation of Liability</h2>
        <p>
          Zakayo Apparel shall not be liable for any indirect, incidental, special, consequential or punitive damages
          resulting from your use of the website or any products purchased through the website.
        </p>
        <h2>7. Governing Law</h2>
        <p>
          These Terms of Service shall be governed by and construed in accordance with the laws of the jurisdiction in
          which Zakayo Apparel is registered.
        </p>
        <h2>8. Changes to Terms</h2>
        <p>
          We reserve the right to update or modify these Terms of Service at any time without prior notice. Your
          continued use of the website following any changes indicates your acceptance of the new Terms of Service.
        </p>
      </div>
    </div>
  )
}

