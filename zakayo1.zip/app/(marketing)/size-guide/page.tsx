import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const sizeGuide = [
  { size: "XS", chest: "32-34", waist: "26-28", hips: "34-36" },
  { size: "S", chest: "35-37", waist: "29-31", hips: "37-39" },
  { size: "M", chest: "38-40", waist: "32-34", hips: "40-42" },
  { size: "L", chest: "41-43", waist: "35-37", hips: "43-45" },
  { size: "XL", chest: "44-46", waist: "38-40", hips: "46-48" },
]

export default function SizeGuidePage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Size Guide</h1>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Size</TableHead>
            <TableHead>Chest (inches)</TableHead>
            <TableHead>Waist (inches)</TableHead>
            <TableHead>Hips (inches)</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sizeGuide.map((row) => (
            <TableRow key={row.size}>
              <TableCell>{row.size}</TableCell>
              <TableCell>{row.chest}</TableCell>
              <TableCell>{row.waist}</TableCell>
              <TableCell>{row.hips}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

