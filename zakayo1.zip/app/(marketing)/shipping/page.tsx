import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ShippingPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Shipping Information</h1>
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Domestic Shipping</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-6 space-y-2">
              <li>Standard Shipping (3-5 business days): $5.99</li>
              <li>Express Shipping (1-2 business days): $12.99</li>
              <li>Free shipping on orders over $100</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>International Shipping</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-6 space-y-2">
              <li>Standard International (7-14 business days): $19.99</li>
              <li>Express International (3-5 business days): $39.99</li>
              <li>Please note that additional customs fees may apply</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Tracking Your Order</CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              Once your order is shipped, you will receive a confirmation email with a tracking number. You can use this
              number to track your package on our website or the carrier's website.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

