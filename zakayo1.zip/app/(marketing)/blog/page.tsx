import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const blogPosts = [
  {
    id: 1,
    title: "Summer Fashion Trends 2023",
    excerpt: "Discover the hottest styles for the upcoming summer season.",
    date: "2023-05-15",
  },
  {
    id: 2,
    title: "Sustainable Fashion: A Guide to Eco-Friendly Clothing",
    excerpt: "Learn how to make environmentally conscious choices in your wardrobe.",
    date: "2023-05-10",
  },
  {
    id: 3,
    title: "How to Build a Capsule Wardrobe",
    excerpt: "Simplify your closet and maximize your outfit options with these tips.",
    date: "2023-05-05",
  },
]

export default function BlogPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Blog</h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {blogPosts.map((post) => (
          <Card key={post.id}>
            <CardHeader>
              <CardTitle>{post.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{post.excerpt}</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <span className="text-sm text-gray-500">{post.date}</span>
              <Link href={`/blog/${post.id}`} className="text-blue-500 hover:underline">
                Read more
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

