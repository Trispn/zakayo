export default function PrivacyPolicyPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
      <div className="prose max-w-none">
        <p>Last updated: May 20, 2023</p>
        <h2>1. Introduction</h2>
        <p>
          Welcome to Zakayo Apparel's Privacy Policy. This policy describes how we collect, use, and protect your
          personal information when you use our website and services.
        </p>
        <h2>2. Information We Collect</h2>
        <p>
          We collect information you provide directly to us, such as when you create an account, make a purchase, or
          contact our customer service. This may include your name, email address, shipping address, and payment
          information.
        </p>
        <h2>3. How We Use Your Information</h2>
        <p>
          We use your information to process orders, provide customer service, send promotional emails (if you've opted
          in), and improve our website and services.
        </p>
        <h2>4. Data Security</h2>
        <p>
          We implement a variety of security measures to maintain the safety of your personal information when you place
          an order or enter, submit, or access your personal information.
        </p>
        <h2>5. Changes to This Policy</h2>
        <p>
          We may update this privacy policy from time to time. We will notify you of any changes by posting the new
          privacy policy on this page.
        </p>
        <h2>6. Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us at privacy@zakayoapparel.com.</p>
      </div>
    </div>
  )
}

