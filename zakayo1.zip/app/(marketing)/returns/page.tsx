import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function ReturnsPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Returns and Exchanges</h1>

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="item-1">
          <AccordionTrigger>What is your return policy?</AccordionTrigger>
          <AccordionContent>
            We offer a 30-day return policy for all unused items in their original packaging. Items must be returned
            within 30 days of the purchase date for a full refund.
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-2">
          <AccordionTrigger>How do I initiate a return?</AccordionTrigger>
          <AccordionContent>
            To initiate a return, please log into your account and go to the "Order History" section. Select the item
            you wish to return and follow the prompts to generate a return label.
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-3">
          <AccordionTrigger>Can I exchange an item?</AccordionTrigger>
          <AccordionContent>
            Yes, you can exchange items within 30 days of purchase. Please follow the same process as returns, but
            select "Exchange" instead of "Return" when initiating the process.
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-4">
          <AccordionTrigger>How long does it take to process a return?</AccordionTrigger>
          <AccordionContent>
            Once we receive your return, it typically takes 3-5 business days to process. Refunds are usually credited
            back to your original payment method within 7-10 business days.
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

