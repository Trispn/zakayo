import { ProductGrid } from "@/components/product-grid"

export default function ShopPage() {
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">SHOP ALL</h1>
      <ProductGrid />
    </div>
  )
}

