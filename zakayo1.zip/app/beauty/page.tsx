import { ProductGrid } from "@/components/product-grid"

export default function BeautyPage() {
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">BEAUTY</h1>
      <ProductGrid />
    </div>
  )
}

