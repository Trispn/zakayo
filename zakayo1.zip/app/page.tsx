import { ProductGrid } from "@/components/product-grid"
import { HeroSection } from "@/components/hero-section"
import { CategoryNav } from "@/components/category-nav"
import { ProductAd } from "@/components/product-ad"

export default function HomePage() {
  return (
    <div className="flex flex-col gap-8">
      <HeroSection />
      <CategoryNav />
      <section className="container py-8">
        <h2 className="mb-8 text-3xl font-bold tracking-tight">New Mood Enhancing Arrivals</h2>
        <ProductGrid />
      </section>
      <ProductAd />
    </div>
  )
}

