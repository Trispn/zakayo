"use client"

import { Card } from "@/components/ui/card"
import { Overview } from "@/components/admin/overview"
import { MostSoldItems } from "@/components/admin/most-sold-items"
import { LatestOrders } from "@/components/admin/latest-orders"
import { Badge } from "@/components/ui/badge"
import { ArrowUpIcon, ArrowDownIcon } from "lucide-react"

const placeholderData = {
  todaySales: 7140000,
  todayRevenue: 2870000,
  inProcess: 6370000,
  // Add more placeholder data as needed
}

export default function AdminDashboard() {
  return (
    <div className="p-6 bg-[#1a1f37] min-h-screen text-white">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-semibold">Zakayo Mood Apparel Dashboard</h1>
        <select className="bg-[#242b4a] text-white border-0 rounded-md p-2">
          <option>28 Jan 2024 - 28 Dec 2024</option>
        </select>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
        <Card className="bg-[#242b4a] border-0 p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-400">Today Sales</p>
              <h3 className="text-2xl font-bold mt-2">UGX {placeholderData.todaySales}</h3>
              <div className="flex items-center mt-2">
                <Badge variant="success" className="bg-green-500/20 text-green-500">
                  <ArrowUpIcon className="w-3 h-3 mr-1" />
                  +12.5%
                </Badge>
                <span className="text-gray-400 text-sm ml-2">vs last month</span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
              <div className="w-8 h-8 rounded-full bg-blue-500" />
            </div>
          </div>
        </Card>

        <Card className="bg-[#242b4a] border-0 p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-400">Today Revenue</p>
              <h3 className="text-2xl font-bold mt-2">UGX {placeholderData.todayRevenue}</h3>
              <div className="flex items-center mt-2">
                <Badge variant="success" className="bg-green-500/20 text-green-500">
                  <ArrowUpIcon className="w-3 h-3 mr-1" />
                  +8.1%
                </Badge>
                <span className="text-gray-400 text-sm ml-2">vs last month</span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
              <div className="w-8 h-8 rounded-full bg-green-500" />
            </div>
          </div>
        </Card>

        <Card className="bg-[#242b4a] border-0 p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-400">In Process</p>
              <h3 className="text-2xl font-bold mt-2">UGX {placeholderData.inProcess}</h3>
              <div className="flex items-center mt-2">
                <Badge variant="destructive" className="bg-red-500/20 text-red-500">
                  <ArrowDownIcon className="w-3 h-3 mr-1" />
                  -2.4%
                </Badge>
                <span className="text-gray-400 text-sm ml-2">vs last month</span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center">
              <div className="w-8 h-8 rounded-full bg-orange-500" />
            </div>
          </div>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3 mb-8">
        <Card className="bg-[#242b4a] border-0 p-4 lg:col-span-2">
          <h3 className="text-lg font-semibold mb-4">Total Revenue</h3>
          <div className="flex items-center gap-4 mb-4">
            <h4 className="text-2xl font-bold">UGX 17,640,000</h4>
            <Badge variant="success" className="bg-green-500/20 text-green-500">
              +8% from last month
            </Badge>
          </div>
          <Overview className="mt-4 text-gray-400" />
        </Card>
        <Card className="bg-[#242b4a] border-0 p-4">
          <h3 className="text-lg font-semibold mb-4">Most Sold Mood Items</h3>
          <MostSoldItems />
        </Card>
      </div>

      <Card className="bg-[#242b4a] border-0 p-4">
        <h3 className="text-lg font-semibold mb-4">Latest Orders</h3>
        <LatestOrders />
      </Card>
    </div>
  )
}

