"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  ShoppingBag,
  FileText,
  DollarSign,
  Settings,
  Users,
  Bell,
  User,
  BarChart2,
  MessageSquare,
  Menu,
} from "lucide-react"
import { useState, useEffect } from "react"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleResize = () => setMobileMenuOpen(window.innerWidth >= 768)
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-[#1a1f37]">
      <aside className="w-full md:w-64 bg-[#242b4a] p-4">
        <div className="flex items-center gap-2 mb-8 px-2">
          <div className="w-8 h-8 bg-primary rounded-lg" />
          <span className="font-bold text-white">ZAKAYO</span>
        </div>
        <button className="md:hidden w-full text-white mb-4" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          <Menu className="h-6 w-6" />
        </button>
        {(mobileMenuOpen || window.innerWidth >= 768) && (
          <nav className="space-y-2 max-h-[calc(100vh-6rem)] overflow-y-auto">
            <Link href="/admin">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin" ? "bg-[#1a1f37]" : ""}`}
              >
                <LayoutDashboard className="mr-2 h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <Link href="/admin/products">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/products" ? "bg-[#1a1f37]" : ""}`}
              >
                <ShoppingBag className="mr-2 h-4 w-4" />
                Products
              </Button>
            </Link>
            <Link href="/admin/orders">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/orders" ? "bg-[#1a1f37]" : ""}`}
              >
                <FileText className="mr-2 h-4 w-4" />
                Orders
              </Button>
            </Link>
            <Link href="/admin/payments">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/payments" ? "bg-[#1a1f37]" : ""}`}
              >
                <DollarSign className="mr-2 h-4 w-4" />
                Payments
              </Button>
            </Link>
            <Link href="/admin/users">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/users" ? "bg-[#1a1f37]" : ""}`}
              >
                <Users className="mr-2 h-4 w-4" />
                Users
              </Button>
            </Link>
            <Link href="/admin/messages">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/messages" ? "bg-[#1a1f37]" : ""}`}
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                Messages
              </Button>
            </Link>
            <Link href="/admin/notifications">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/notifications" ? "bg-[#1a1f37]" : ""}`}
              >
                <Bell className="mr-2 h-4 w-4" />
                Notifications
              </Button>
            </Link>
            <Link href="/admin/analytics">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/analytics" ? "bg-[#1a1f37]" : ""}`}
              >
                <BarChart2 className="mr-2 h-4 w-4" />
                Analytics
              </Button>
            </Link>
            <Link href="/admin/profile">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/profile" ? "bg-[#1a1f37]" : ""}`}
              >
                <User className="mr-2 h-4 w-4" />
                Profile
              </Button>
            </Link>
            <Link href="/admin/settings">
              <Button
                variant="ghost"
                className={`w-full justify-start text-white hover:bg-[#1a1f37] ${pathname === "/admin/settings" ? "bg-[#1a1f37]" : ""}`}
              >
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
            </Link>
          </nav>
        )}
      </aside>
      <main className="flex-1 p-4">{children}</main>
    </div>
  )
}

