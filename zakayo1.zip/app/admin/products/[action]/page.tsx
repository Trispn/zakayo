"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { addProduct, updateProduct, getProduct, type Product } from "@/lib/db"
import { useToast } from "@/components/ui/use-toast"

type ProductFormData = Omit<Product, "id">

const emptyProduct: ProductFormData = {
  name: "",
  description: "",
  price: 0,
  image: "",
  category: "",
  featured: false,
  inStock: true,
}

export default function ProductForm({ params }: { params: { action: string; id?: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const [formData, setFormData] = useState<ProductFormData>(emptyProduct)
  const [imageFile, setImageFile] = useState<File | null>(null)

  const isEditing = params.action === "edit"

  useEffect(() => {
    if (isEditing && params.id) {
      getProduct(params.id).then((product) => {
        if (product) {
          setFormData(product)
        } else {
          toast({
            title: "Error",
            description: "Product not found",
            variant: "destructive",
          })
          router.push("/admin/products")
        }
      })
    }
  }, [isEditing, params.id, router, toast])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      let imageUrl = formData.image
      if (imageFile) {
        imageUrl = await uploadImage(imageFile)
      }

      const productData = { ...formData, image: imageUrl }

      if (isEditing && params.id) {
        await updateProduct(params.id, productData)
      } else {
        await addProduct(productData)
      }

      toast({
        title: "Success",
        description: `Product ${isEditing ? "updated" : "added"} successfully`,
      })
      router.push("/admin/products")
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${isEditing ? "update" : "add"} product`,
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string) => {
    setFormData((prev) => ({ ...prev, [name]: !prev[name as keyof ProductFormData] }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0])
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h1 className="text-2xl font-bold mb-6">{isEditing ? "Edit Product" : "Add Product"}</h1>

      <div>
        <Label htmlFor="name">Product Name</Label>
        <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleInputChange}
          required
        />
      </div>

      <div>
        <Label htmlFor="price">Price</Label>
        <Input
          id="price"
          name="price"
          type="number"
          step="0.01"
          value={formData.price}
          onChange={handleInputChange}
          required
        />
      </div>

      <div>
        <Label htmlFor="image">Image</Label>
        <Input id="image" name="image" type="file" accept="image/*" onChange={handleImageChange} />
      </div>

      <div>
        <Label htmlFor="category">Category</Label>
        <Select
          defaultValue={formData.category}
          onValueChange={(value) => setFormData({ ...formData, category: value })}
        >
          <SelectTrigger id="category">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="clothing">Clothing</SelectItem>
            <SelectItem value="shoes">Shoes</SelectItem>
            <SelectItem value="accessories">Accessories</SelectItem>
            <SelectItem value="beauty">Beauty</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="featured">Featured</Label>
        <Switch
          id="featured"
          checked={formData.featured}
          onCheckedChange={(checked) => setFormData({ ...formData, featured: checked })}
        />
      </div>

      <div className="flex items-center space-x-2">
        <Checkbox id="inStock" checked={formData.inStock} onCheckedChange={() => handleCheckboxChange("inStock")} />
        <Label htmlFor="inStock">In Stock</Label>
      </div>

      <Button type="submit">{isEditing ? "Update Product" : "Add Product"}</Button>
    </form>
  )
}

async function uploadImage(file: File): Promise<string> {
  // Replace with your actual image upload logic
  const formData = new FormData()
  formData.append("image", file)
  const response = await fetch("/api/upload", { method: "POST", body: formData })
  const data = await response.json()
  return data.url
}

