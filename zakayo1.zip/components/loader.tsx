import { Logo } from "@/components/logo"

export function Loader() {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-white z-50">
      <Logo className="h-16 w-16 animate-pulse" />
    </div>
  )
}

