"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"

const ads = [
  {
    id: 1,
    title: "Summer Collection",
    description: "Discover our new summer styles",
    image: "/placeholder.svg",
    link: "/summer-collection",
  },
  {
    id: 2,
    title: "Exclusive Deals",
    description: "Up to 50% off on selected items",
    image: "/placeholder.svg",
    link: "/sale",
  },
  // Add more ads as needed
]

export function ProductAd() {
  const [currentAd, setCurrentAd] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentAd((prev) => (prev + 1) % ads.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  return (
    <section className="container py-8">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentAd}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="relative h-96 overflow-hidden rounded-lg"
        >
          <Image
            src={ads[currentAd].image || "/placeholder.svg"}
            alt={ads[currentAd].title}
            layout="fill"
            objectFit="cover"
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-50 text-white">
            <h3 className="text-3xl font-bold mb-2">{ads[currentAd].title}</h3>
            <p className="text-xl mb-4">{ads[currentAd].description}</p>
            <Button asChild>
              <a href={ads[currentAd].link}>Shop Now</a>
            </Button>
          </div>
        </motion.div>
      </AnimatePresence>
    </section>
  )
}

