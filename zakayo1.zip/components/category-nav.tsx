"use client"

import * as React from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"
import { ChevronRight } from "lucide-react"

const categories = {
  clothing: [
    { title: "All Dresses", href: "/clothing/dresses" },
    { title: "Asymmetrical", href: "/clothing/asymmetrical" },
    { title: "Maxi", href: "/clothing/maxi" },
    { title: "Mini", href: "/clothing/mini" },
    { title: "Midi", href: "/clothing/midi" },
  ],
  shoes: [
    { title: "All Shoes", href: "/shoes" },
    { title: "Boots", href: "/shoes/boots" },
    { title: "Heels", href: "/shoes/heels" },
    { title: "Sneakers", href: "/shoes/sneakers" },
  ],
  accessories: [
    { title: "All Accessories", href: "/accessories" },
    { title: "Jewelry", href: "/accessories/jewelry" },
    { title: "Bags", href: "/accessories/bags" },
    { title: "Belts", href: "/accessories/belts" },
  ],
}

export function CategoryNav() {
  return (
    <NavigationMenu className="container hidden md:flex">
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuTrigger>Clothing</NavigationMenuTrigger>
          <NavigationMenuContent>
            <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
              {categories.clothing.map((item) => (
                <ListItem key={item.title} title={item.title} href={item.href} />
              ))}
            </ul>
          </NavigationMenuContent>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <NavigationMenuTrigger>Shoes</NavigationMenuTrigger>
          <NavigationMenuContent>
            <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
              {categories.shoes.map((item) => (
                <ListItem key={item.title} title={item.title} href={item.href} />
              ))}
            </ul>
          </NavigationMenuContent>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <NavigationMenuTrigger>Accessories</NavigationMenuTrigger>
          <NavigationMenuContent>
            <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
              {categories.accessories.map((item) => (
                <ListItem key={item.title} title={item.title} href={item.href} />
              ))}
            </ul>
          </NavigationMenuContent>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  )
}

const ListItem = React.forwardRef<React.ElementRef<"a">, React.ComponentPropsWithoutRef<"a">>(
  ({ className, title, children, href, ...props }, ref) => {
    return (
      <li>
        <NavigationMenuLink asChild>
          <Link
            ref={ref}
            href={href ?? "#"}
            className={cn(
              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
              className,
            )}
            {...props}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium leading-none mb-1">{title}</div>
                {children && <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">{children}</p>}
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </div>
          </Link>
        </NavigationMenuLink>
      </li>
    )
  },
)
ListItem.displayName = "ListItem"

