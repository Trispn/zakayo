import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"

const orders = [
  {
    id: "81232",
    product: "Happy Tee",
    customer: "Alex Kerev",
    date: "Jan 24 2022",
    amount: "UGX 350,000",
    status: "Delivered",
  },
  {
    id: "81233",
    product: "Calm Hoodie",
    customer: "Alex Kerev",
    date: "Jan 25 2022",
    amount: "UGX 875,000",
    status: "Pending",
  },
  {
    id: "81234",
    product: "Energetic Pants",
    customer: "Alex Kerev",
    date: "Jan 26 2022",
    amount: "UGX 210,000",
    status: "Cancelled",
  },
  {
    id: "81235",
    product: "Confident Jacket",
    customer: "Alex Kerev",
    date: "Jan 27 2022",
    amount: "UGX 525,000",
    status: "Delivered",
  },
]

export function LatestOrders() {
  return (
    <div className="relative overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="border-gray-800">
            <TableHead className="text-gray-400">Product</TableHead>
            <TableHead className="text-gray-400">Order ID</TableHead>
            <TableHead className="text-gray-400">Date</TableHead>
            <TableHead className="text-gray-400">Customer</TableHead>
            <TableHead className="text-gray-400">Status</TableHead>
            <TableHead className="text-gray-400">Amount</TableHead>
            <TableHead className="text-gray-400">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id} className="border-gray-800">
              <TableCell>{order.product}</TableCell>
              <TableCell>{order.id}</TableCell>
              <TableCell>{order.date}</TableCell>
              <TableCell>{order.customer}</TableCell>
              <TableCell>
                <Badge
                  variant={
                    order.status === "Delivered" ? "success" : order.status === "Pending" ? "warning" : "destructive"
                  }
                  className={
                    order.status === "Delivered"
                      ? "bg-green-500/20 text-green-500"
                      : order.status === "Pending"
                        ? "bg-yellow-500/20 text-yellow-500"
                        : "bg-red-500/20 text-red-500"
                  }
                >
                  {order.status}
                </Badge>
              </TableCell>
              <TableCell>{order.amount}</TableCell>
              <TableCell>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

