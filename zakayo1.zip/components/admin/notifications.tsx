import { Bell, Package, ShoppingCart, User } from "lucide-react"

const notifications = [
  {
    id: 1,
    title: "New Order",
    description: "Order #12345 has been placed",
    icon: ShoppingCart,
    time: "5 minutes ago",
  },
  {
    id: 2,
    title: "Low Stock Alert",
    description: "T-Shirt stock is below reorder point",
    icon: Package,
    time: "1 hour ago",
  },
  {
    id: 3,
    title: "New User Registration",
    description: "John Doe has created an account",
    icon: User,
    time: "2 hours ago",
  },
]

export function Notifications() {
  return (
    <div className="space-y-4">
      {notifications.map((notification) => (
        <div key={notification.id} className="flex items-start space-x-4">
          <div className="rounded-full bg-blue-500 p-2">
            <notification.icon className="h-4 w-4 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-medium">{notification.title}</h3>
            <p className="text-sm text-gray-500">{notification.description}</p>
            <span className="text-xs text-gray-400">{notification.time}</span>
          </div>
        </div>
      ))}
    </div>
  )
}

