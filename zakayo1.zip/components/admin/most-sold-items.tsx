"use client"

import { Progress } from "@/components/ui/progress"

const items = [
  { name: "Happy Tees", percentage: 75 },
  { name: "Calm Hoodies", percentage: 65 },
  { name: "Energetic Pants", percentage: 55 },
  { name: "Confident Jackets", percentage: 45 },
  { name: "Relaxed Accessories", percentage: 35 },
]

export function MostSoldItems() {
  return (
    <div className="space-y-4">
      {items.map((item) => (
        <div key={item.name} className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>{item.name}</span>
            <span>{item.percentage}%</span>
          </div>
          <Progress value={item.percentage} className="h-2" />
        </div>
      ))}
    </div>
  )
}

