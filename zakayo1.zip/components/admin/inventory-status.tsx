import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const inventoryData = [
  { id: 1, name: "T-Shirt", category: "Clothing", stock: 150, reorderPoint: 50 },
  { id: 2, name: "Jeans", category: "Clothing", stock: 80, reorderPoint: 30 },
  { id: 3, name: "Sneakers", category: "Shoes", stock: 60, reorderPoint: 20 },
  { id: 4, name: "Backpack", category: "Accessories", stock: 40, reorderPoint: 15 },
  { id: 5, name: "Watch", category: "Accessories", stock: 25, reorderPoint: 10 },
]

export function InventoryStatus() {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Category</TableHead>
          <TableHead>Stock</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {inventoryData.map((item) => (
          <TableRow key={item.id}>
            <TableCell>{item.name}</TableCell>
            <TableCell>{item.category}</TableCell>
            <TableCell>{item.stock}</TableCell>
            <TableCell>
              {item.stock > item.reorderPoint ? (
                <span className="text-green-600">In Stock</span>
              ) : (
                <span className="text-red-600">Low Stock</span>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

