"use client"

import { useState } from "react"
import Image from "next/image"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Product } from "@/lib/db"

interface QuickViewProps {
  product: Product
  onClose: () => void
}

export function QuickView({ product, onClose }: QuickViewProps) {
  const [selectedSize, setSelectedSize] = useState("")

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{product.name}</DialogTitle>
          <DialogDescription>{product.designer}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="aspect-[3/4] relative overflow-hidden rounded-lg">
            <Image src={product.image || "/placeholder.svg"} alt={product.name} layout="fill" objectFit="cover" />
          </div>
          <p className="text-lg font-semibold">AU$ {product.price.toFixed(2)}</p>
          <Select value={selectedSize} onValueChange={setSelectedSize}>
            <SelectTrigger>
              <SelectValue placeholder="Select size" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="xs">XS</SelectItem>
              <SelectItem value="s">S</SelectItem>
              <SelectItem value="m">M</SelectItem>
              <SelectItem value="l">L</SelectItem>
              <SelectItem value="xl">XL</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => console.log(`Added ${product.name} to cart`)}>Add to Cart</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

