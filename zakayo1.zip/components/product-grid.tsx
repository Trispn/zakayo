"use client"

import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
// Remove this import
// import { getProducts } from "@/lib/db"
import { useState } from "react"
import { QuickView } from "@/components/quick-view"

// Add this placeholder data
const placeholderProducts = [
  {
    id: "1",
    name: "Happy Tee",
    designer: "Zakayo",
    price: 29.99,
    image: "/placeholder.svg",
  },
  {
    id: "2",
    name: "Calm Hoodie",
    designer: "Zakayo",
    price: 59.99,
    image: "/placeholder.svg",
  },
  // Add more placeholder products as needed
]

export function ProductGrid() {
  // Replace the useState line with this:
  const [products, setProducts] = useState(placeholderProducts)
  const [quickViewProduct, setQuickViewProduct] = useState(null)

  return (
    <div className="space-y-6">
      <motion.div
        className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {products.map((product, index) => (
          <motion.div
            key={product.id}
            className="group relative"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <div className="aspect-[3/4] w-full overflow-hidden">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={300}
                height={400}
                className="h-full w-full object-cover object-center transition-transform duration-300 group-hover:scale-105"
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-2 h-8 w-8 rounded-full bg-white/70 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Heart className="h-4 w-4" />
                <span className="sr-only">Add to wishlist</span>
              </Button>
            </div>
            <div className="mt-4 flex justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-900">
                  <Link href={`/product/${product.id}`}>
                    <span aria-hidden="true" className="absolute inset-0" />
                    {product.name}
                  </Link>
                </h3>
                <p className="mt-1 text-sm text-gray-500">{product.designer}</p>
              </div>
              <p className="text-sm font-medium text-gray-900">AU$ {product.price.toFixed(2)}</p>
            </div>
            <Button
              variant="ghost"
              className="absolute bottom-0 left-0 right-0 mx-auto w-2/3 opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={() => setQuickViewProduct(product)}
            >
              Quick View
            </Button>
          </motion.div>
        ))}
      </motion.div>
      {quickViewProduct && <QuickView product={quickViewProduct} onClose={() => setQuickViewProduct(null)} />}
    </div>
  )
}

