import Link from "next/link"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative bg-black text-white">
      <div className="container flex flex-col items-center justify-center space-y-4 py-32 text-center">
        <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">ZAKAYO APPAREL</h1>
        <p className="mx-auto max-w-[700px] text-zinc-200 md:text-xl">Discover luxury fashion, accessories, and more</p>
        <Button asChild variant="outline" className="bg-transparent text-white hover:bg-white hover:text-black">
          <Link href="/new">Shop New Arrivals</Link>
        </Button>
      </div>
    </section>
  )
}

