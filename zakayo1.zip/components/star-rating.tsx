import { Star } from "lucide-react"

interface StarRatingProps {
  rating: number
  max?: number
  onRatingChange?: (rating: number) => void
  editable?: boolean
}

export function StarRating({ rating, max = 5, onRatingChange, editable = false }: StarRatingProps) {
  return (
    <div className="flex">
      {[...Array(max)].map((_, i) => (
        <Star
          key={i}
          className={`${i < rating ? "text-yellow-400" : "text-gray-300"} ${editable ? "cursor-pointer" : ""}`}
          fill={i < rating ? "currentColor" : "none"}
          onClick={() => editable && onRatingChange && onRatingChange(i + 1)}
        />
      ))}
    </div>
  )
}

