"use client"

import { useState } from "react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

const filterCategories = [
  {
    name: "Designer",
    options: ["Balenciaga", "Gucci", "Off-White", "Prada", "Saint Laurent"],
  },
  {
    name: "Size",
    options: ["XS", "S", "M", "L", "XL"],
  },
  {
    name: "Color",
    options: ["Black", "Blue", "Green", "Red", "White"],
  },
]

export function Filters() {
  const [selectedFilters, setSelectedFilters] = useState<Record<string, string[]>>({})

  const handleFilterChange = (category: string, option: string) => {
    setSelectedFilters((prev) => {
      const categoryFilters = prev[category] || []
      if (categoryFilters.includes(option)) {
        return {
          ...prev,
          [category]: categoryFilters.filter((item) => item !== option),
        }
      } else {
        return {
          ...prev,
          [category]: [...categoryFilters, option],
        }
      }
    })
  }

  return (
    <Accordion type="multiple" className="w-full">
      {filterCategories.map((category) => (
        <AccordionItem key={category.name} value={category.name}>
          <AccordionTrigger>{category.name}</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {category.options.map((option) => (
                <div key={option} className="flex items-center space-x-2">
                  <Checkbox
                    id={`${category.name}-${option}`}
                    checked={selectedFilters[category.name]?.includes(option)}
                    onCheckedChange={() => handleFilterChange(category.name, option)}
                  />
                  <Label htmlFor={`${category.name}-${option}`}>{option}</Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  )
}

