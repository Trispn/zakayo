"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { ShoppingBag, User, Search, Menu, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { CartSheet } from "@/components/cart-sheet"
import { Logo } from "@/components/logo"

const navigation = [
  { name: "NEW", href: "/new" },
  { name: "DESIGNERS", href: "/designers" },
  { name: "CLOTHING", href: "/clothing" },
  { name: "SHOES", href: "/shoes" },
  { name: "BAGS", href: "/bags" },
  { name: "ACCESSORIES", href: "/accessories" },
  { name: "BEAUTY", href: "/beauty" },
  { name: "SALE", href: "/sale" },
]

export function Header() {
  const pathname = usePathname()
  const [isCartOpen, setIsCartOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full bg-white">
      <div className="container">
        <div className="flex h-16 items-center justify-between border-b">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                className="px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 lg:hidden"
              >
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[300px] sm:w-[400px]">
              <div className="flex flex-col h-full">
                <div className="flex-1">
                  <nav className="flex flex-col gap-4">
                    {navigation.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="text-sm font-medium transition-colors hover:text-gray-600"
                      >
                        {item.name}
                      </Link>
                    ))}
                  </nav>
                </div>
                <div className="border-t pt-4">
                  <Link href="/search" className="flex items-center py-2">
                    <Search className="mr-2 h-4 w-4" />
                    <span>Search</span>
                  </Link>
                  <Link href="/profile" className="flex items-center py-2">
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </Link>
                  <Link href="/wishlist" className="flex items-center py-2">
                    <Heart className="mr-2 h-4 w-4" />
                    <span>Wishlist</span>
                  </Link>
                  <Button variant="ghost" className="w-full justify-start py-2" onClick={() => setIsCartOpen(true)}>
                    <ShoppingBag className="mr-2 h-4 w-4" />
                    <span>Cart</span>
                    <Badge className="ml-auto">3</Badge>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
          <Link href="/" className="flex items-center space-x-2">
            <Logo className="h-8 w-8" />
            <span className="font-bold text-xl uppercase tracking-wide">Zakayo</span>
          </Link>
          <nav className="hidden lg:flex lg:gap-6">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`text-sm font-medium transition-colors hover:text-gray-600 ${
                  pathname === item.href ? "text-gray-900" : "text-gray-500"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>
          <div className="flex items-center space-x-4">
            <Link href="/search" className="hidden lg:block">
              <Button variant="ghost" size="icon">
                <Search className="h-5 w-5" />
                <span className="sr-only">Search</span>
              </Button>
            </Link>
            <Link href="/profile" className="hidden lg:block">
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">Profile</span>
              </Button>
            </Link>
            <Link href="/wishlist" className="hidden lg:block">
              <Button variant="ghost" size="icon">
                <Heart className="h-5 w-5" />
                <span className="sr-only">Wishlist</span>
              </Button>
            </Link>
            <Button variant="ghost" size="icon" onClick={() => setIsCartOpen(true)}>
              <ShoppingBag className="h-5 w-5" />
              <Badge className="absolute -top-1 -right-1 h-4 w-4 rounded-full p-0 text-[10px]">3</Badge>
              <span className="sr-only">Cart</span>
            </Button>
          </div>
        </div>
      </div>
      <CartSheet open={isCartOpen} onOpenChange={setIsCartOpen} />
    </header>
  )
}

